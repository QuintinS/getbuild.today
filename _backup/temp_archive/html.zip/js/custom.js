$(document).ready(function() {
	$('.expander a').on('click', function(event){
		event.preventDefault();
		$('.black-bar').toggle(0, function(){
			$('.navigation-bar').slideToggle();	
		});
		if ($(this).html() == '+'){
			$(this).html('-');
		}else {
			$(this).html('+');
		}
	});
	
	$('input[type=radio][name=domain-type]').change(function() {
		console.log($(this).val());
		if ($(this).val() == 'registered'){
			$('.domain-name').removeClass('hidden');
		}else {
			$('.domain-name').addClass('hidden');
		}
		
		if ($(this).val() == 'register'){
			$('.domain-register').removeClass('hidden');
			$('.proceed-payment').addClass('hidden');
		}else {
			$('.proceed-payment').removeClass('hidden');
			$('.domain-register').addClass('hidden');
		}
		
	})
});